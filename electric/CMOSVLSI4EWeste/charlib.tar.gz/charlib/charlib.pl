#!/usr/bin/perl 
# You might have to change the path above for your perl installation
 
#########################################################################
# charlib.pl
#########################################################################

# (c) 12/20/97 David Harris  harrisd@alum.mit.edu
# Updated 2/05/03 Genevieve Breed gbreed@hmc.edu
#
# This program characterizes a standard cell library.  It requires two
# user-created input files:
#
#  charlib.lst:  a list of gates to characterize with desired stimulus
#                the first gate must be the inverter with logical effort 1
#  netlist.hsp:  a file containing netlists of all the gates to characterize
# (2/05/03 Netlist.hsp removed and substituted with a folder of all the gates)
#
# It also requires the charlib.hsp SPICE deck and a directory called archive.
# Finally, you need to have HSPICE and perl on your workstation.

# Usage:  charlib.pl VDD LAMBDA processfile [-v] [-a]
# Ex:  charlib.pl 5.0 1.0u orbit2.0u/opConditions.lib
#
#  characterizes a 2.0 micron MOSIS process at VDD=5v
#
#  -a (accurate):  cause SPICE to use the .option accurate mode
#                  for more accurate but slower simulation
#  -v (verbose):   save SPICE decks and stimulus files for later reference
#				   and print status of characterization run

#########################################################################
# Load Libraries
#########################################################################

require "ctime.pl";
require "flush.pl";

#########################################################################
# Start Script
#########################################################################

&checkargs();

# Start timer
$time = time;

#########################################################################
# Run Simulations
#########################################################################

open (RESULTS, ">char.out");
print RESULTS "\n*** Library Characterization Results ***\n\n";
print RESULTS "$0 $VDD $LAMBDA $processfile\n";

open(CHARLIST, "charlib.lst");

# Process each gate.  The first gate must be the reference inverter
$done = 0; $first = 1; $pw="20ns"; $verbose = 0;
do {
    &readgate();
} while ($done == 0);

# Finish timer
$date = &ctime(time); chop($date); # get current date and strip off newline
$time = time-$time;

#########################################################################
# Print Results
#########################################################################

print RESULTS "\n\nRun completed $date in $time seconds\n\n";
close (RESULTS);

#########################################################################
# Subroutines
#########################################################################

# The subroutines provide a quick way to kick off simulations
# and extract the results computed by SPICE.  

#########################################################################
# sub: checkargs
#########################################################################

sub checkargs{
    # Check for proper number of arguments and extract args
    if ($#ARGV < 2) { 
	# $#ARGV is the number of command line arguments minus 1
	print STDERR "Usage: $0 VDD LAMBDA processfile [-v] [-a]\n"; 
	# $0 is this script name
	print STDERR " ex: $0 1.8 0.09u ../models/tsmc180/opConditions.lib\n";
	exit;
    }
    $VDD = $ARGV[0]; $LAMBDA = $ARGV[1]; $processfile = $ARGV[2];
    
    if ($#ARGV > 2) {
	for ($i=3; $i <= $#ARGV; $i++) {
	    if ($ARGV[$i] eq "-v") {
		$verbose = 1;
	    }
	    if ($ARGV[$i] eq "-a") {
		$accurate = 1;
	    }
	}
    }
}

#########################################################################
# sub: readgate
#########################################################################

sub readgate {
    $ports=0;
    $gate="";
    while (<CHARLIST>) {
   chomp;
	if (/^\#/ || /^\W*$/) { 
      next; 
   } # skip comments & blank lines
	if (/^in\s*(\S*)/) { 
	    $name[$ports] = $1;
	    $dir[$ports++] = "in";
	    next;
	}
	if (/^out\s*(\S*)/) { 
	    $name[$ports] = $1;
	    $dir[$ports++] = "out";
	    next;
	}
	if (/^GATE\s*(\S*)/) {
	    if ($gate ne "") {
		die("$_ encountered before ENDGATE");
	    }
	    $gate = $1; # name of gate
	    $printheader = 1;
      print "found $_ $gate \n";
	    next;
	}
	if (/^ENDGATE/) { return };
	if (/^END/) {
	    $done=1; return;
	}
	
	# otherwise, it is a simulation run
	if ($gate eq "") {
	    die("Missing GATE type.\n");
	}
	@stim = split(" ",$_);
	print "Processing gate $gate with stimulus: @stim \n";
	if ($#stim != $ports-1) {
	    die("Wrong number of arguments in '$_'");
	}
	&chargate();
    }
    $done = 1;
}

#########################################################################
# sub: chargate
#########################################################################

sub chargate {
    local ($i, $j);
    
    # Set up stimulus file
    open(STIM,">stim.hsp");
    
    # Check main input and which output is being measured
    $mainin = ""; $whichout = ""; 
    for ($i=0; $i <= $#stim; $i++) {
    	if ($dir[$i] eq "out") {
	    if ($stim[$i] eq "*") {
		if ($whichout ne "") {
		    die("Attempted to measure multiple outputs in single stimulus of gate $gate\n");
		}
		$whichout = $name[$i];
	    }
    	}
	if ($dir[$i] eq "in") {
	   if ($stim[$i] eq "r" || $stim[$i] eq "f" || $stim[$i] eq "*") { 
	       if ($mainin ne "") {
		   die("More than one main input given *, r, or f on gate $gate\n");
	       }
	       $mainin = $stim[$i];
	   }
       }
    }
    if ($whichout eq "") {
    	die("No output * on gate $gate\n");
    }
    if ($mainin eq "") {
	die("No main input *, r, or f on gate $gate\n");
    }

    # Hook up gate
    print(STIM ".subckt gate in ins inb out\n");
    print(STIM "xdut ");
    # Print inputs and outputs
    for ($j=0; $j <= $#stim; $j++) {
	if ($dir[$j] eq "in") {
	    if ($stim[$j] eq "1") {
		print (STIM "VDD ");
	    }
	    elsif ($stim[$j] eq "0") {
		print (STIM "GND ");
	    }
	    elsif ($stim[$j] eq "*" || $stim[$j] eq "r" ||
		   $stim[$j] eq "f") {
		print(STIM "in ");
	    }
	    elsif($stim[$j] eq "s") {
		print (STIM "ins ");
	    }
	    elsif ($stim[$j] eq "b") {
		print (STIM "inb ");
	    }
	    else {
		die ("Bad stimulus $stim[$j] on input $name[$j] of gate $gate");
	    }
	}
	elsif ($dir[$j] eq "out") {
	    if ($stim[$j] eq "*") {
		print (STIM "out "); # connect to next stage
	    }
	    elsif($stim[$j] eq "x") {
		print (STIM "$name[$j] ");
	    }
	    else {
		die ("Bad stimulus $stim[$j] on output $name[$j] of gate $gate");
	    }
	}
	else {
	    # This point should never be reached
	    die ("Bad terminal direction $dir[$j] on input $name[$j] of gate $gate");
	}
    }
    print(STIM "$gate\n");
    print(STIM ".ends\n\n");
    
    # Create Input stimulus & output measurements
    if ($mainin eq "*" || $mainin eq "r") {
	print (STIM "Vin0 in0 GND pulse 0 'Supply' 0.25ns 0.05ns 0.05ns $pw '2 * $pw'\n");
    }
    else {
	print (STIM "Vin0 in0 GND pulse 'Supply' 0 0.25ns 0.05ns 0.05ns $pw '2 * $pw'\n");
    }
    print(STIM "\n");

    # Measure rising, falling, and average delay
    @cases = ();
    if ($mainin eq "*" || $mainin eq "r") {
	print(STIM ".measure tfall\n");
	print(STIM "+ TRIG v(in3) VAL='Supply/2' RISE=1\n");
	print(STIM "+ TARG v(in4) VAL='Supply/2' FALL=1\n");
	push(@cases, "fall");
    }
    if ($mainin eq "*" || $mainin eq "f") {
	print(STIM ".measure trise\n");
	print(STIM "+ TRIG v(in3) VAL='Supply/2' FALL=1\n");
	print(STIM "+ TARG v(in4) VAL='Supply/2' RISE=1\n");
	push(@cases, "rise");
    }
    if ($mainin eq "*") {
	print(STIM ".measure tavg PARAM='(trise+tfall)/2'\n");
	push(@cases, "avg");
    }
    close(STIM);
    
    # run simulation
    &printheader();

    foreach $fanout (2, 4, 6, 8) {
	foreach $case (@cases) {
	$result[$fanout]{$case} = &runsim("charlib","t$case", "!GATE!", $gate,
					  "!CORNER!", "TT", "!VOLT!", $VDD,
					  "!FANOUT!", $fanout, "!IC!", $VDD);
        }
    }
    foreach $case (@cases) {
	
	# Curve fit parasitic p and logical effort g from simulations
	&linearFit($result[2]{$case}, 2, 
		   $result[4]{$case}, 4, 
		   $result[6]{$case}, 6, $result[8]{$case}, 8);
	$result_p = $a; $result_g = $b; 
	# This is a clumsy way to pass parameters
	
	if ($verbose == 1) {
	    printf("    $case: p = $result_p g = $result_g\n");
	}
	if ($result_g == 0) {
	    die("logical effort = 0 on gate $gate; maybe bad spice deck");
	}
	
	# Grab the logical effort and parasitics of an inverter
	if ($first == 1 && $case eq "avg") {
	    $tau = $result_g;
	    $pw = 150*$tau;
	    $first = 0;
        printf(RESULTS  "tau = %3.5f \n", $tau * 1e12);
	}
	
	for($j=0; $j<=$#stim; $j++) {
	    printf(RESULTS "%-4s",$stim[$j]);
	}
	printf(RESULTS "%-4s %3.4f * h + %4.4f", 
	       $case, $result_g*1e12, $result_p*1e12);
	if ($first == 0) {
	    printf(RESULTS " (g=%1.4f p=%1.4f)", $result_g / $tau,
		   $result_p / $tau);
	}
	printf(RESULTS "\n");
    }
	
    # Archive results
    if ($verbose == 1) {
	$run = join("", @stim);
	system("cp tmp_deck.hsp archive/$gate$run.hsp");
	system("cp stim.hsp archive/$gate$run.stim");
	system("cp tmp_deck.lis archive/$gate$run.out");
    }

    print(RESULTS "\n");
	&flush(RESULTS);
}

#########################################################################
# sub: printheader
#########################################################################

sub printheader {
    local($i);

    if ($printheader == 1) {
	print(RESULTS "$gate\n");
	for ($i=0; $i<=$#stim; $i++) {
	    printf(RESULTS "%-4s",$name[$i]);
	}
	printf(RESULTS "%-4s %-6s\n",  "Case", "Delay (ps)");
	$printheader = 0;
    }
}

#########################################################################
# sub: runsim
#########################################################################

# This subroutine takes the name of the HSPICE deck and a measured
# parameter value to extract as inputs.
# It substitutes the values of VDD and processfile you provide
# for the variables !VDD! and !LIB! in the HSPICE deck and
# also handles any other substitutions you passed.  It then
# runs HSPICE and extracts the value of the parameter you specified found
# by a .measure statement in the deck.

sub runsim {
    local ($i);
    
    $olddeckname = $deckname;
     @old = @subs; # save old arguments
    @subs = @_; # Grab list of arguments to substitute

    $deckname = shift(@subs); # Grab deckname passed to runsim
    $measure = shift(@subs); # Grab parameter to measure

    if($verbose == 1) {
	print "Extracting $measure from $deckname with:\n  ";
    }
    for ($i=0; $i<=$#subs; $i+=2) {
		print "$subs[$i] = $subs[$i+1]  ";
    }
    print "\n";

    # If old arguments are the same as new ones, recycle old results
    $recycle = 1; # don't recycle for this problem
    for ($i=0; $i<=$#subs; $i++) {
 	if (($olddeckname ne $deckname)||($old[$i] ne $subs[$i])) {
	    $recycle = 0;
	}
    }
    if ($recycle != 1) {
	# Open the spice deck and a temporary output file
	open(DECK, $deckname.".hsp") 
	    || die("Can't open $deckname.hsp: $!\n");
	open(OUT, "> tmp_deck.hsp") || die("Can't open tmp_deck.hsp: $!\n");

	# if accurate = 1, set .options accurate
	$acc = ($accurate == 1) ? "ACC" : "";

	# Read each line of the deck, substitute VDD & procfile, write out
	while (<DECK>) {
	    s/!SUP!/$VDD/g;
	    s/!LAMBDA!/$LAMBDA/g;
	    s/!LIB!/$processfile/g;
	    s/!ACCURATE!/$acc/g;
	    for ($i=0; $i<=$#subs; $i+=2) { 
			s/$subs[$i]/$subs[$i+1]/g; # replace all occurrences
	    }
	    print OUT $_;
	}

	# Close files
	close(OUT);
	close(DECK);

	# Run HSPICE simulation
	# Close STDERR while running to avoid messages printed by SPICE
	open(SAVEERR, ">&STDERR");
	close(STDERR);
	#system("hspice tmp_deck.lis tmp_deck.hsp"); # Windows
	#system("hspice tmp_deck.hsp tmp_deck.lis"); # Windows (latest hspice)
	system("hspice tmp_deck.hsp > tmp_deck.lis"); # Unix
	open(STDERR, ">&SAVEERR");
	close(SAVEERR);
    }

    # Extract result from output file
    open(RESULT, "tmp_deck.lis") || die("Can't open tmp_deck.lis: $!\n");
    $result = "";
    while (<RESULT>) {
	if (/\*\*error/) { # HSPICE produced an error
	    print STDERR "$_";
	    $next = <RESULT>;
	    die("$next");
	}
	if (/\s*$measure\s*=\s*(\S+)/i) { # Search for $measure = xxx
	    $result = $1; last; # and record xxx
	}
    }
    if ($result eq "") {
	die ("Couldn't find $measure\n");
    }
    printf("  $measure = $result\n");
    return $result;
}

#########################################################################
# sub: linearfit
#########################################################################

# This subroutine takes a list of (y, x) pairs and does a least squares
# curve fit to the equation y = a + b*x.  It leaves a and b in
# global variables $a and $b.  Clumsy, but it works...
#
# Least squares finds the best solution to Ap=q:
# 
# p' = [a b]^T = (A^T * A)^-1 * A^T * q
#
# where ^T indicates transpose and ^-1 indicates inverse.
# A is the matrix: [ 1 x1 ]
#                  [ 1 x2 ]
#                  [ 1 x3 ]
#                    ...
#                  [ 1 xm ]
# p' is [a b]^T, the best solution,  and q is [y1 y2 y3 ... ym]^T.
#
# This math isn't very important; as long as you call the subroutine
# as given in the inverter example, you should get the right answer.

sub linearFit {
    local($i, @prod, $det, @inv, @atq);
    @input = @_; # in format (y1, x1, y2, x2, y3, x3, ..., ym, xm)

    # compute A^T * A
    $prod[0] = $prod[1] = $prod[2] = $prod[3] = 0;
    for ($i = 0; $i <= $#input; $i += 2) {
	$prod[0]++;
	$prod[1] += $input[$i+1];
	$prod[2] += $input[$i+1];
	$prod[3] += $input[$i+1]*$input[$i+1];
    }
    
    # invert A^T * A
    $det = $prod[0] * $prod[3] - $prod[1] * $prod[2]; 
    if ($det == 0) { # trap error
	print " Error: division by zero during least squares\n";
	$a = 0; $b = 0;
	return;
    }
    $inv[0] = $prod[3]/$det;
    $inv[1] = -$prod[1]/$det;
    $inv[2] = -$prod[2]/$det;
    $inv[3] = $prod[0]/$det;
    
    # compute A^T * q
    $atq[0] = $atq[1] = 0;
    for ($i=0; $i <= $#input; $i += 2) {
	$atq[0] += $input[$i];
	$atq[1] += $input[$i] * $input[$i+1];
    }
    
    # compute p' = INV * ATQ
    $a = $inv[0] * $atq[0] + $inv[1] * $atq[1];
    $b = $inv[2] * $atq[0] + $inv[3] * $atq[1];
}
